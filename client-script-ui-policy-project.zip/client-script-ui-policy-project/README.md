# ServiceNow: Client Scripts & UI Policies (Incident)

Hands-on project implementing 6 Client Scripts and 4 UI Policies on the Incident table.

## Contents
- `client_scripts/` - source of each script (onLoad, onChange x3, onSubmit, onCellEdit)
- `ui_policies/` - documentation of each UI Policy, conditions, and actions
- `import_xml/` - importable XML for a Personal Developer Instance (PDI)
- `TEST_PLAN.md` - how to verify everything

## Import (PDI)
Import in this order, using **Import XML** (right-click list header > Import XML):
1. `System Definition > Client Scripts` -> `sys_script_client.xml`
2. `System UI > UI Policies` -> `sys_ui_policy.xml`
3. `System UI > UI Policy Actions` -> `sys_ui_policy_action.xml`

## Manual setup
Studio or `System Definition > Client Scripts` / `System UI > UI Policies`; copy each script from `client_scripts/` and set Table = Incident, Type and Field as in each file header.

## Client Script vs UI Policy
| | Client Script | UI Policy |
|---|---|---|
| Best for | Complex logic, validation, async lookups | Show/hide, mandatory, read-only |
| Code needed | Always | No-code (script optional) |
| Reverses automatically | No | Yes (Reverse if false) |
| Runs | onLoad/onChange/onSubmit/onCellEdit | On load and on condition change |

Rule of thumb: use a UI Policy first; use a Client Script when it can't do the job.

Note: field names such as `hold_reason` and `close_code` can vary by instance/version; adjust if needed.
