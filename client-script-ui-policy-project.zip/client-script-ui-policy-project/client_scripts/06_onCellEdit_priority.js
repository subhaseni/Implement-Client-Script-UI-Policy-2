/**
 * INC - OnCellEdit Block P1 From List
 * Table: incident | Type: onCellEdit | Field: priority
 * Prevents setting Priority 1 via list inline edit.
 */
function onCellEdit(sysIDs, table, oldValues, newValue, callback) {
    var saveAndClose = true;
    if (newValue == '1') {
        alert('Priority 1 cannot be set from the list. Please open the record.');
        saveAndClose = false;
    }
    callback(saveAndClose);
}
