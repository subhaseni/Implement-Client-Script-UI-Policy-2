/**
 * INC - OnChange Impact Urgency Hint
 * Table: incident | Type: onChange | Field: impact
 * Shows a field message when impact is High.
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading) {
        return;
    }
    if (newValue == '1') {
        g_form.showFieldMsg('impact', 'High impact: confirm with the caller that many users are affected.', 'info');
    } else {
        g_form.hideFieldMsg('impact', true);
    }
}
