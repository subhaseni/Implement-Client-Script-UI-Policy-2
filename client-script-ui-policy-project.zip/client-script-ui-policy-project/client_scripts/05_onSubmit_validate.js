/**
 * INC - OnSubmit Validate
 * Table: incident | Type: onSubmit
 * Blocks submit when short description is too short or resolved without notes.
 */
function onSubmit() {
    var shortDesc = g_form.getValue('short_description') || '';
    if (shortDesc.trim().length < 10) {
        g_form.showFieldMsg('short_description', 'Short description must be at least 10 characters.', 'error');
        return false;
    }
    var state = g_form.getValue('state');
    if ((state == '6' || state == '7') && !g_form.getValue('close_notes')) {
        g_form.showFieldMsg('close_notes', 'Close notes are required to resolve or close.', 'error');
        return false;
    }
    return true;
}
