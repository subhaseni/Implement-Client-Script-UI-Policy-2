/**
 * INC - OnLoad Welcome and Defaults
 * Table: incident | Type: onLoad
 * Runs when form opens: focuses short description on new records, shows info for P1.
 */
function onLoad() {
    // New record: guide the user
    if (g_form.isNewRecord()) {
        g_form.addInfoMessage('Please describe the issue clearly in the Short description.');
        g_form.setValue('contact_type', 'self-service');
        g_form.setMandatory('short_description', true);
    }
    // Existing P1 incident: warn the agent
    if (!g_form.isNewRecord() && g_form.getValue('priority') == '1') {
        g_form.addErrorMessage('This is a Priority 1 incident - respond immediately.');
    }
}
