/**
 * INC - OnChange Category Clears Subcategory
 * Table: incident | Type: onChange | Field: category
 * When category changes, clear subcategory and show a hint.
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }
    g_form.clearValue('subcategory');
    g_form.hideFieldMsg('subcategory');
    g_form.showFieldMsg('subcategory', 'Select a subcategory for "' + newValue + '".', 'info');
}
