/**
 * INC - OnChange Caller VIP Alert
 * Table: incident | Type: onChange | Field: caller_id
 * Looks up caller record (client-side GlideRecord-free via getReference) and flags VIPs.
 */
function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || newValue === '') {
        return;
    }
    // Asynchronous reference lookup (best practice: always pass a callback)
    g_form.getReference('caller_id', function (caller) {
        if (caller && caller.vip == 'true') {
            g_form.showFieldMsg('caller_id', 'VIP caller - handle with priority.', 'error');
        } else {
            g_form.hideFieldMsg('caller_id', true);
        }
    });
}
