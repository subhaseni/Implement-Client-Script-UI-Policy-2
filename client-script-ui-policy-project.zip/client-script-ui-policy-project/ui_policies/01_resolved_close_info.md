# INC - Resolved requires close info

- Table: incident
- Condition: `state=6^ORstate=7`
- On load: true | Reverse if false: True
- Run scripts: False

When State is Resolved/Closed, show and make mandatory Close code and Close notes.

| Field | Visible | Mandatory | Read-only |
|---|---|---|---|
| close_code | true | true | ignore |
| close_notes | true | true | ignore |
