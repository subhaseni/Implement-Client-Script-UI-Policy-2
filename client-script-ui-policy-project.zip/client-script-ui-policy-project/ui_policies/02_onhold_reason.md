# INC - On Hold requires reason

- Table: incident
- Condition: `state=3`
- On load: true | Reverse if false: True
- Run scripts: False

When State is On Hold, show and require Hold reason.

| Field | Visible | Mandatory | Read-only |
|---|---|---|---|
| hold_reason | true | true | ignore |
