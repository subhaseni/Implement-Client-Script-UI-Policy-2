# INC - Closed is read-only

- Table: incident
- Condition: `state=7`
- On load: true | Reverse if false: True
- Run scripts: False

When State is Closed, make key fields read-only.

| Field | Visible | Mandatory | Read-only |
|---|---|---|---|
| short_description | ignore | ignore | true |
| description | ignore | ignore | true |
| category | ignore | ignore | true |
