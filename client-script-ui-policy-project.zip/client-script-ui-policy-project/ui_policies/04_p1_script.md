# INC - P1 script policy

- Table: incident
- Condition: `priority=1`
- On load: true | Reverse if false: True
- Run scripts: True

Priority 1 makes Assignment group mandatory and runs scripts for true/false.

| Field | Visible | Mandatory | Read-only |
|---|---|---|---|
| assignment_group | ignore | true | ignore |

## Execute if true
```js
g_form.addInfoMessage('P1 incident: assignment group is mandatory.');
```
## Execute if false
```js
g_form.clearMessages();
```
