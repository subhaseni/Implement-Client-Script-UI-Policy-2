# Test Plan
1. Open new Incident -> info message appears; Contact type = self-service.
2. Change Category -> Subcategory clears, hint shows.
3. Set Caller to a VIP user -> red VIP message.
4. Set Impact = 1 - High -> hint shows.
5. Save with Short description under 10 chars -> blocked.
6. Set State = Resolved with no notes -> Close code/notes mandatory; submit blocked without notes.
7. Set State = On Hold -> Hold reason shown and mandatory.
8. Set State = Closed -> short description, description, category read-only.
9. Priority 1 -> Assignment group mandatory + info message; change away -> cleared.
10. Incident list: inline edit Priority to 1 -> alert and edit rejected.
